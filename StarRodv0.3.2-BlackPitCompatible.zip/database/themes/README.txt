
Custom Themes:

Star Rod can use custom themes desgined for IntelliJ via a .theme.json file.
You can browse a collection of such themes here:

https://plugins.jetbrains.com/search?headline=0-theme&tags=Theme

Find a theme you like and click "Souce File" to browse for the necessary file.
Place the file anywhere in this folder and the custom theme will show up in
the theme editor when you run Star Rod.
