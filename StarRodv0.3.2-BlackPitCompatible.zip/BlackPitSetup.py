#!/usr/bin/env python3

def append_string_to_file(misc_file_path, misc_search_string, misc_string_to_append):
    # Open the file in append mode
    with open(misc_file_path, 'a+') as file:
        # Read the contents of the file
        file.seek(0)  # Move the file pointer to the beginning
        contents = file.read()

        # Search for the string
        if misc_search_string not in contents:
            # If the string is not found, append it to the file
            file.write(misc_string_to_append + '\n')


misc_file_path = 'database/types/misc.txt'
misc_search_string = '.Default = 0'
misc_string_to_append = '.Default = 0'


elements_file_path = 'database/types/battle/elements.enum'
elements_search_string = 'Mystery00000000 = 0'
elements_string_to_append = '\nMystery00000000 = 0'

partners_file_path = 'database/types/partners.enum'
partners_search_string = '0 = Empty'
partners_string_to_append = '0 = Empty'

# Call the function
append_string_to_file(misc_file_path, misc_search_string, misc_string_to_append)
append_string_to_file(elements_file_path, elements_search_string, elements_string_to_append)
append_string_to_file(partners_file_path, partners_search_string, partners_string_to_append)